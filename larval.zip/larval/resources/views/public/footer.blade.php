<script charset="utf-8" src="{{ asset('js/jquery.min.js?v=2.1.4') }}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/validate/jquery.validate.min.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/validate/messages_zh.min.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/checkvaildate.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/bootstrap.min.js?v=3.3.6') }}"></script>
<script charset="utf-8" src="{{ asset('js/content.min.js?v=1.0.0') }}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/chosen/chosen.jquery.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/iCheck/icheck.min.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/sweetalert/sweetalert.min.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/switchery/switchery.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/jquery.form.js')}}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/zTree/jquery.ztree.all.min.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/layer/layer.js')}}" ></script>
<script charset="utf-8" src="{{ asset('js/layer/extend/layer.ext.js')}}" ></script>
<script charset="utf-8" src="{{ asset('js/laypage/laypage.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/laytpl/laytpl.js') }}"></script>
<script charset="utf-8" src="{{ asset('js/plugins/layer/laydate/laydate.js')}}"></script>
<script>
    $(document).ready(function(){

        $(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green"});

    });
</script>