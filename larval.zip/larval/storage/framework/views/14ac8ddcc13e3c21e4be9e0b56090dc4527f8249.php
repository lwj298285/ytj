<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="IE=edge" >
    <meta name="renderer" content="webkit">
    <link rel="shortcut icon" href="favicon.ico">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    
    <link href="<?php echo e(asset('css/bootstrap.min.css?v=3.3.6')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/font-awesome.min.css?v=4.4.0')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/plugins/iCheck/custom.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/plugins/chosen/chosen.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/plugins/switchery/switchery.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/style.min.css?v=4.1.0')); ?>style.min.css?v=4.1.0" rel="stylesheet">
    <link href="<?php echo e(asset('css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/div.css')); ?>" rel="stylesheet" type="text/css">
    <link  href="<?php echo e(asset('js/plugins/zTree/zTreeStyle.css')); ?>" rel="stylesheet" type="text/css">
    
    <style type="text/css">
        .long-tr th{
            text-align: center
        }
        .long-td td{
            text-align: center
        }
    </style>
</head>