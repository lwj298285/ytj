/*::
declare module 'exit-on-epipe' {};

declare module 'xlsx' { declare var exports:XLSXModule; };
declare module '../' { declare var exports:XLSXModule; };

declare module 'commander' { declare var exports:any; };
declare module './jszip.js' { declare var exports:any; };
declare module './dist/cpexcel.js' { declare var exports:any; };
declare module 'crypto' { declare var exports:any; };
declare module 'fs' { declare var exports:any; };

type ZIP = any;
*/
