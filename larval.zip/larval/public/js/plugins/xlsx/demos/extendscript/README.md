# ExtendScript demos

The main file is `test.jsx`.  Target-specific files prepend target directives.

Copy the `test.jsx` file as well as the `shim.js`, `jszip.js` and `xlsx.flow.js`
files to wherever you want the scripts to reside.  The demo shows opening a file
and converting to an array of arrays.
