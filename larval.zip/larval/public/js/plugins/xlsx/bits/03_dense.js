var DENSE = null;
